package nio.manager.simulation.client;

import java.beans.PropertyChangeListener;

public interface NIOManagerSimulationOutCoupler extends PropertyChangeListener {
	void localProcessingOnly(boolean newVal);
	
}
