package nio.manager.simulation.client;

public interface NIOManagerSimulationProcessor extends Runnable {

}
