package nio.manager.simulation.server;

import inputport.nio.manager.listeners.SocketChannelReadListener;

public interface NIOManagerSimulationServerReceiver extends SocketChannelReadListener{

}
