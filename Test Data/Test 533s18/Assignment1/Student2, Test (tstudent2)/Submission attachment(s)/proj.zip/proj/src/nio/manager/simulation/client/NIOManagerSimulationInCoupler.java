package nio.manager.simulation.client;

import inputport.nio.manager.listeners.SocketChannelReadListener;

public interface NIOManagerSimulationInCoupler extends SocketChannelReadListener, Runnable{

}
