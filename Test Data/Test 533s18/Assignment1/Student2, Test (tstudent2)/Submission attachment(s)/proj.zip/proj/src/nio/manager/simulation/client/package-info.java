/**
 * 
 */
/**
 * @author Dewan
 *
 */
package nio.manager.simulation.client;