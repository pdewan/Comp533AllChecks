/**
 * 
 */
/**
 * @author Dewan
 *
 */
package nio.manager.simulation.common;